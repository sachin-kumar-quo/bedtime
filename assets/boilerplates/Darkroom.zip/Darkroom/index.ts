export { default, assets } from "./Darkroom";
